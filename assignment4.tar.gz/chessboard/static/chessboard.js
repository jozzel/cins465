const MovePiece = () => {


  let src = document.getElementById("src").value  //<!-- gets Value of src ex. e2 -->
  let dst = document.getElementById("dst").value  //<!-- gets value of dest ex. e4 -->
  document.getElementById('src').value = ''; //setting the value of the source input string to nothing
  document.getElementById('dst').value = ''; //setting the value of the destination input string to nothing

  let src_piece = document.getElementById(src);
  let chesspiece = src_piece.innerHTML //<!-- gets the actual pawn/chess piece -->
  document.getElementById(dst).innerHTML = chesspiece //<!-- Now chess piece is at the destination space -->
  src_piece.innerHTML = ''; //<!-- chess piece is moved and it is now empty space -->

}


const ResetPiece = () => {

  window.location.reload()

}
