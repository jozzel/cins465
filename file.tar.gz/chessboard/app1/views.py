from django.shortcuts import render

# Create your views here.

from django.http import HttpResponse

def home(request):
    page_data = {
 "rows": [
 {"a8": '&#9820;', "a7": '&#9822;' , "a6": '&#9821;', "a5": '&#9819;', "a4": '&#9818;', "a3": '&#9821;', "a2": '&#9822;', "a1": '&#9820;'},
 {"b8": '&#9823;', "b7": '&#9823;', "b6": '&#9823;', "b5": '&#9823;', "b4": '&#9823;', "b3": '&#9823;', "b2": '&#9823;', "b1": '&#9823;'},
 {"c8": '&nbsp;', "c7": '&nbsp;', "c6": '&nbsp;', "c5": '&nbsp;', "c4": '&nbsp;', "c3": '&nbsp;', "c2": '&nbsp;', "c1": '&nbsp;'},
 {"d8": '&nbsp;', "d7": '&nbsp;', "d6": '&nbsp;', "d5": '&nbsp;', "d4": '&nbsp;', "d3": '&nbsp;', "d2": '&nbsp;', "d1": '&nbsp;'},
 {"e8": '&nbsp;', "e7": '&nbsp;', "e6": '&nbsp;', "e5": '&nbsp;', "e4": '&nbsp;', "e4": '&nbsp;', "e2": '&nbsp;', "e1": '&nbsp;'},
 {"f8": '&nbsp;', "f7": '&nbsp;', "f6": '&nbsp;', "f5": '&nbsp;', "f4": '&nbsp;', "f3": '&nbsp;', "f2": '&nbsp;', "f1": '&nbsp;'},
 {"g8": '&#9817;', "g7": '&#9817;', "g6": '&#9817;', "g5": '&#9817;', "g4": '&#9817;', "g3": '&#9817;', "g2": '&#9817;', "g1": '&#9817;'},
 {"h8": '&#9814;', "h7": '&#9816;', "h6": '&#9815;', "h5": '&#9813;', "h4": '&#9812;', "h3": '&#9815;', "h2": '&#9816;', "h1": '&#9814;'},
 ]
}
    return render(request, 'app1/home.html')

def history(request):
    return render(request, 'app1/history.html')


def rules(request):
    return render(request, 'app1/rules.html')

def about(request):
    return render(request, 'app1/about.html')
